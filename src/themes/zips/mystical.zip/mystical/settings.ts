import { ChatSettings } from '../../types';


export const themeSettings: ChatSettings = {
	isDemo: true,
	alignment: 'left',
	fontSize: 26,
	scrollAnimation: true,
	animation: true,
};
